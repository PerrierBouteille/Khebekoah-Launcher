/**
 * @author Luuxis
 * @license CC-BY-NC 4.0 - https://creativecommons.org/licenses/by-nc/4.0/
 */

import { EventEmitter } from 'events';
const loaderDownloader = require('minecraft-loader');


export default class MinecraftLoader {
    options: any;
    on: any;
    emit: any;
    constructor(options: any) {
        this.options = options;
        this.on = EventEmitter.prototype.on;
        this.emit = EventEmitter.prototype.emit;
    }

    async GetLoader(version: any, javaPath: any) {
        let loader = new loaderDownloader({
            path: `${this.options.path}/loader/${this.options.loader.type}`,
            timeout: this.options.timeout,
            downloadFileMultiple: this.options.downloadFileMultiple,
            autoClean: true,
            loader: {
                type: this.options.loader.type,
                version: version,
                build: this.options.loader.build,
                config: {
                    javaPath: javaPath,
                    minecraftJar: `${this.options.path}/versions/${version}/${version}.jar`,
                    minecraftJson: `${this.options.path}/versions/${version}/${version}.json`
                }
            }
        });
        return await new Promise((resolve, reject) => {
            loader.install();

            loader.on('json', (json: any) => {
                let loaderJson = json;
                loaderJson.libraries = loaderJson.libraries.map((lib: any) => {
                    lib.loader = `${this.options.path}/loader/${this.options.loader.type}`;
                    return lib;
                });

                resolve(loaderJson);
            });

            loader.on('extract', (extract: any) => {
                this.emit('extract', extract);
            });

            loader.on('progress', (progress: any, size: any, element: any) => {
                this.emit('progress', progress, size, element);
            });

            loader.on('check', (progress: any, size: any, element: any) => {
                this.emit('check', progress, size, element);
            });

            loader.on('patch', (patch: any) => {
                this.emit('patch', patch);
            });

            loader.on('error', (err: any) => {
                reject(err);
            });
        })
    }

    async GetArguments(json: any, version: any) {
        if (json === null) {
            return {
                game: [],
                jvm: []
            }
        }

        let moddeArguments = json.arguments;
        if (!moddeArguments) return { game: [], jvm: [] };
        let Arguments: any = {}
        if (moddeArguments.game) Arguments.game = moddeArguments.game;
        if (moddeArguments.jvm) Arguments.jvm = moddeArguments.jvm.map(jvm => {
            return jvm
                .replace(/\${version_name}/g, version)
                .replace(/\${library_directory}/g, `${this.options.path}/loader/${this.options.loader.type}/libraries`)
                .replace(/\${classpath_separator}/g, process.platform === 'win32' ? ';' : ':');
        })

        return {
            game: Arguments.game || [],
            jvm: Arguments.jvm || [],
            mainClass: json.mainClass
        };
    }
}