<?php
$instance['aynor'] = array_merge($instance['aynor'], array(
    "loadder" => array(
        "minecraft_version" => "1.16.5",
        "loadder_type" => "forge",
        "loadder_version" => "latest"
    )
));

$instance['hypixel'] = array_merge($instance['hypixel'], array(
    "loadder" => array(
        "minecraft_version" => "1.8.9",
        "loadder_type" => "forge",
        "loadder_version" => "latest"
    )
));

$instance['selvania'] = array_merge($instance['selvania'], array(
    "loadder" => array(
        "minecraft_version" => "latest_release",
        "loadder_type" => "none",
        "loadder_version" => "latest"
    )
));
?>